# memcached-cli
A cli tool to access your memcached cache
