import click

@click.group()
def cli():
    """Welcome to Memclid"""
    """A CLI tool for your memcached server"""
    pass