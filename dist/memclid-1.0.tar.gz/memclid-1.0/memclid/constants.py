STATUS_DATA_AVAILABLE="Data fetched successfully"
STATUS_DATA_NOT_AVAILABLE="Data not available"
STATUS_RECORD_STORED="Record stored successfully"
STATUS_RECORD_NOT_STORED="Record could not be stored"